export const FireBaseConfig = {
  apiKey: "AIzaSyBW0jyY-8uri8T86qCMiQXabt-8mhbkdLg",
  authDomain: "site-deivisondfs2.firebaseapp.com",
  databaseURL: "https://site-deivisondfs2.firebaseio.com",
  projectId: "site-deivisondfs2",
  storageBucket: "site-deivisondfs2.appspot.com",
  messagingSenderId: "430769371570"
}
