export class Jobs {
  name: string;
}
